﻿document.addEventListener('DOMContentLoaded', function () {
    const conciertos = JSON.parse(localStorage.getItem('conciertos')) || [];
    const tableBody = document.querySelector('#concertsTable tbody');

    conciertos.forEach((concierto, index) => {
        const row = document.createElement('tr');

        row.innerHTML = `
                            <td>${concierto.nombre}</td>
                            <td>${concierto.artista}</td>
                            <td>${concierto.fecha}</td>
                            <td>${concierto.lugar}</td>
                            <td>${concierto.aforo}</td>
                            <td>${concierto.precio}</td>
                            <td>
                                <button onclick="editConcert(${index})">Editar</button>
                                <button onclick="deleteConcert(${index})">Eliminar</button>
                            </td>
                        `;

        tableBody.appendChild(row);
    });
});

function deleteConcert(index) {
    let conciertos = JSON.parse(localStorage.getItem('conciertos')) || [];
    conciertos.splice(index, 1);  
    localStorage.setItem('conciertos', JSON.stringify(conciertos));
    location.reload();  
}

function editConcert(index) {
    const concierto = JSON.parse(localStorage.getItem('conciertos'))[index];
    const nombre = prompt('Editar nombre del concierto:', concierto.nombre);
    const artista = prompt('Editar nombre del artista:', concierto.artista);
    const fecha = prompt('Editar fecha del concierto:', concierto.fecha);
    const lugar = prompt('Editar lugar del concierto:', concierto.lugar);
    const aforo = prompt('Editar capacidad del concierto:', concierto.aforo);
    const precio = prompt('Editar precio del concierto:', concierto.precio);

    if (nombre && artista && fecha && lugar && aforo && precio) {
        let conciertos = JSON.parse(localStorage.getItem('conciertos'));
        conciertos[index] = { nombre, artista, fecha, lugar, aforo: parseInt(aforo), precio: parseFloat(precio) };
        localStorage.setItem('conciertos', JSON.stringify(conciertos));
        location.reload();  
    }
}