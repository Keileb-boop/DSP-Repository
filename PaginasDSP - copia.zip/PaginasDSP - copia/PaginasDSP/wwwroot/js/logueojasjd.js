﻿document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // USUARIOS
    if (username === 'admin' && password === '12345') {
        alert('Inicio de sesión exitoso como admin');
        window.location.href = '/Home/conciertoadd';
        //USUARIO ADMINISTRADOR¿R¿¿


    } else if (username === 'caleb@gmail.com' && password === 'calebpenate2003') {
        // USUARIO CALEB
        alert('Inicio de sesión exitoso como usuario');
        window.location.href = '/Home/usuariopag';
    }
    else if (username === 'camil@gmail.com' && password === 'camocastillo') {
        // USUARIO CAMILA
        alert('Inicio de sesión exitoso como usuario');
        window.location.href = '/Home/usuariopag';
    }

    else if (username === 'darkspikel@gmail.com' && password === 'darwin1314') {
        // USUARIO DARWIN
        alert('Inicio de sesión exitoso como usuario');
        window.location.href = '/Home/usuariopag';
    }

    else if (username === 'cassete@gmail.com' && password === 'cassete2024') {
        // USUARIO CASSETE
        alert('Inicio de sesión exitoso como usuario');
        window.location.href = '/Home/usuariopag';
    }


    else {
        alert('Usuario o contraseña incorrectos');
    }
});