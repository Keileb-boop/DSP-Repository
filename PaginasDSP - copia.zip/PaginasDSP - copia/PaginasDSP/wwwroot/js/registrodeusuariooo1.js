﻿window.onload = function () {
    const conciertos = JSON.parse(localStorage.getItem('conciertos')) || [];
    const concertsDiv = document.getElementById('concerts');

    if (conciertos.length === 0) {
        concertsDiv.innerHTML = '<p>No hay conciertos disponibles.</p>';
    } else {
        conciertos.forEach(concierto => {
            const concertCard = document.createElement('div');
            concertCard.className = 'concert-card';
            concertCard.innerHTML = `
                                <h2>${concierto.nombre}</h2>
                                <p><strong>Artista:</strong> ${concierto.artista}</p>
                                <p><strong>Fecha:</strong> ${concierto.fecha}</p>
                                <p><strong>Lugar:</strong> ${concierto.lugar}</p>
                                <p><strong>Descripción:</strong> ${concierto.descripcion}</p>
                                <p><strong>Capacidad:</strong> ${concierto.aforo}</p>
                                <p><strong>Precio:</strong> $${concierto.precio.toFixed(2)}</p>
                                <button onclick="asistir('${concierto.nombre}')">Asistir</button>
                            `;
            concertsDiv.appendChild(concertCard);
        });
    }
};

function asistir(conciertoNombre) {
    alert(`¡Te has registrado para asistir al concierto: ${conciertoNombre}!`);
}