﻿using Microsoft.AspNetCore.Mvc;
using PaginasDSP.Models;
using System.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;


namespace tesis.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult conciertoadd()
        {
            return View("Views/Home/conciertoadd.cshtml");
        }


        public IActionResult enciclo1()
        {
            return View("Views/Home/enciclo1.cshtml");
        }


        public IActionResult usuariopag()
        {
            return View("Views/Home/usuariopag.cshtml");
        }

        public IActionResult conciertosdisp()
        {
            return View("Views/Home/conciertosdisp.cshtml");
        }

        public IActionResult conciertosusuar()
        {
            return View("Views/Home/conciertosusuar.cshtml");
        }


        public IActionResult usuariosadmin() {
            return View("Views/Home/usuariosadmin.cshtml");
        }


        public IActionResult pagoconciertojasjas()
        {
            return View("Views/Home/pagoconciertojasjas.cshtml");
        }

    }
}