﻿namespace complementario3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridViewNotas = new DataGridView();
            btnCargarDatos = new Button();
            btnCalcularMedia = new Button();
            btnLimpiar = new Button();
            Alumno = new DataGridViewTextBoxColumn();
            Nota = new DataGridViewTextBoxColumn();
            Media = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridViewNotas).BeginInit();
            SuspendLayout();
            // 
            // dataGridViewNotas
            // 
            dataGridViewNotas.AllowUserToOrderColumns = true;
            dataGridViewNotas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewNotas.Columns.AddRange(new DataGridViewColumn[] { Alumno, Nota, Media });
            dataGridViewNotas.Location = new Point(49, 124);
            dataGridViewNotas.Name = "dataGridViewNotas";
            dataGridViewNotas.RowHeadersWidth = 51;
            dataGridViewNotas.Size = new Size(300, 188);
            dataGridViewNotas.TabIndex = 0;
            // 
            // btnCargarDatos
            // 
            btnCargarDatos.Location = new Point(480, 124);
            btnCargarDatos.Name = "btnCargarDatos";
            btnCargarDatos.Size = new Size(207, 29);
            btnCargarDatos.TabIndex = 1;
            btnCargarDatos.Text = "Cargar datos";
            btnCargarDatos.UseVisualStyleBackColor = true;
            btnCargarDatos.Click += btnCargarDatos_Click;
            // 
            // btnCalcularMedia
            // 
            btnCalcularMedia.Location = new Point(480, 176);
            btnCalcularMedia.Name = "btnCalcularMedia";
            btnCalcularMedia.Size = new Size(207, 29);
            btnCalcularMedia.TabIndex = 2;
            btnCalcularMedia.Text = "Calcular media";
            btnCalcularMedia.UseVisualStyleBackColor = true;
            btnCalcularMedia.Click += btnCalcularMedia_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(480, 228);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(207, 29);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // Alumno
            // 
            Alumno.HeaderText = "Alumno";
            Alumno.MinimumWidth = 6;
            Alumno.Name = "Alumno";
            Alumno.Width = 125;
            // 
            // Nota
            // 
            Nota.HeaderText = "Nota";
            Nota.MinimumWidth = 6;
            Nota.Name = "Nota";
            Nota.Width = 125;
            // 
            // Media
            // 
            Media.HeaderText = "Media";
            Media.MinimumWidth = 6;
            Media.Name = "Media";
            Media.Width = 125;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(808, 516);
            Controls.Add(btnLimpiar);
            Controls.Add(btnCalcularMedia);
            Controls.Add(btnCargarDatos);
            Controls.Add(dataGridViewNotas);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewNotas).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridViewNotas;
        private Button btnCargarDatos;
        private Button btnCalcularMedia;
        private Button btnLimpiar;
        private DataGridViewTextBoxColumn Alumno;
        private DataGridViewTextBoxColumn Nota;
        private DataGridViewTextBoxColumn Media;
    }
}
