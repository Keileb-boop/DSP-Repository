namespace complementario3
{
    public partial class Form1 : Form

    {

        private double[,] notas = new double[6, 5];
        private int[] asignaturasPorAlumno = new int[6];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCargarDatos_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            for (int i = 0; i < 6; i++)
            {
                asignaturasPorAlumno[i] = rnd.Next(2, 6); // Entre 2 y 5 asignaturas
                for (int j = 0; j < asignaturasPorAlumno[i]; j++)
                {
                    notas[i, j] = rnd.Next(0, 101); // Notas entre 0 y 100
                }
            }

            MostrarNotas();
        }

        private void MostrarNotas()
        {
            dataGridViewNotas.Rows.Clear();
            for (int i = 0; i < 6; i++)
            {
                string notasAlumno = "";
                for (int j = 0; j < asignaturasPorAlumno[i]; j++)
                {
                    notasAlumno += notas[i, j].ToString() + (j < asignaturasPorAlumno[i] - 1 ? ", " : "");
                }
                double media = CalcularMedia(i);
                dataGridViewNotas.Rows.Add($"Alumno {i + 1}", notasAlumno, media);
            }
        }

        private double CalcularMedia(int alumno)
        {
            double suma = 0;
            for (int j = 0; j < asignaturasPorAlumno[alumno]; j++)
            {
                suma += notas[alumno, j];
            }
            return suma / asignaturasPorAlumno[alumno];
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            dataGridViewNotas.Rows.Clear();
        }

        private void btnCalcularMedia_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 6; i++)
            {
                double media = CalcularMedia(i);
                dataGridViewNotas.Rows[i].Cells[2].Value = media;
            }
        }
    }

}

