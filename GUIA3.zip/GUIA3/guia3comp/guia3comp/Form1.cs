namespace guia3comp
{
    public partial class Form1 : Form
    {
        
        private List<string> nombres;

        public Form1()
        {
            InitializeComponent();
            nombres = new List<string>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            ActualizarLista();
        }

        
        private void botonagregar_Click(object sender, EventArgs e)
        {
            string nuevoNombre = textBox1.Text.Trim(); 
            if (!string.IsNullOrWhiteSpace(nuevoNombre)) 
            {
                nombres.Add(nuevoNombre); 
                ActualizarLista(); 
                MessageBox.Show("Nombre a�adido correctamente.");
                textBox1.Clear(); 
            }
            else
            {
                MessageBox.Show("El nombre no puede estar vac�o.");
            }
        }

        
        private void botonborrar_Click(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1) 
            {
                nombres.RemoveAt(lista.SelectedIndex); 
                ActualizarLista(); 
                MessageBox.Show("Nombre eliminado correctamente.");
            }
            else
            {
                MessageBox.Show("Selecciona un nombre para eliminar.");
            }
        }

        // Modificar nombre
        private void botonmodificar_Click(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1) 
            {
                string nuevoNombre = textBox1.Text.Trim(); 
                if (!string.IsNullOrWhiteSpace(nuevoNombre)) 
                {
                    nombres[lista.SelectedIndex] = nuevoNombre; 
                    ActualizarLista(); 
                    MessageBox.Show("Nombre modificado correctamente.");
                    textBox1.Clear(); 
                }
                else
                {
                    MessageBox.Show("El nombre no puede estar vac�o.");
                }
            }
            else
            {
                MessageBox.Show("Selecciona un nombre para modificar.");
            }
        }

        
        private void ActualizarLista()
        {
            lista.Items.Clear(); 
            foreach (var nombre in nombres)
            {
                lista.Items.Add(nombre); 
            }
        }

        
        private void salir_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        
        private void lista_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lista.SelectedIndex != -1) 
            {
                textBox1.Text = nombres[lista.SelectedIndex]; 
            }
        }
    }
}
