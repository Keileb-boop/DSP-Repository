﻿namespace guia3comp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lista = new ListBox();
            botonagregar = new Button();
            botonborrar = new Button();
            botonmodificar = new Button();
            salir = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // lista
            // 
            lista.FormattingEnabled = true;
            lista.Location = new Point(387, 187);
            lista.Name = "lista";
            lista.Size = new Size(256, 124);
            lista.TabIndex = 0;
            lista.SelectedIndexChanged += lista_SelectedIndexChanged;
            // 
            // botonagregar
            // 
            botonagregar.Location = new Point(104, 140);
            botonagregar.Name = "botonagregar";
            botonagregar.Size = new Size(143, 29);
            botonagregar.TabIndex = 1;
            botonagregar.Text = "Añadir nombre";
            botonagregar.UseVisualStyleBackColor = true;
            botonagregar.Click += botonagregar_Click;
            // 
            // botonborrar
            // 
            botonborrar.Location = new Point(104, 184);
            botonborrar.Name = "botonborrar";
            botonborrar.Size = new Size(143, 29);
            botonborrar.TabIndex = 2;
            botonborrar.Text = "Borrar nombre";
            botonborrar.UseVisualStyleBackColor = true;
            botonborrar.Click += botonborrar_Click;
            // 
            // botonmodificar
            // 
            botonmodificar.Location = new Point(104, 235);
            botonmodificar.Name = "botonmodificar";
            botonmodificar.Size = new Size(143, 29);
            botonmodificar.TabIndex = 3;
            botonmodificar.Text = "Modificar nombre";
            botonmodificar.UseVisualStyleBackColor = true;
            botonmodificar.Click += botonmodificar_Click;
            // 
            // salir
            // 
            salir.Location = new Point(104, 282);
            salir.Name = "salir";
            salir.Size = new Size(143, 29);
            salir.TabIndex = 4;
            salir.Text = "Salir";
            salir.UseVisualStyleBackColor = true;
            salir.Click += salir_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(387, 140);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(256, 27);
            textBox1.TabIndex = 5;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textBox1);
            Controls.Add(salir);
            Controls.Add(botonmodificar);
            Controls.Add(botonborrar);
            Controls.Add(botonagregar);
            Controls.Add(lista);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lista;
        private Button botonagregar;
        private Button botonborrar;
        private Button botonmodificar;
        private Button salir;
        private TextBox textBox1;
    }
}
