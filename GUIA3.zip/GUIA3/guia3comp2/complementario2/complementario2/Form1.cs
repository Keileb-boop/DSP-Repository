namespace complementario2
{
    public partial class Form1 : Form
    {

        private int[,] matriz;
        private int dimension;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtDimension_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnGenerar_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtDimension.Text, out dimension) && dimension > 0)
            {
                matriz = new int[dimension, dimension];
                Random rand = new Random();

                // Limpiar los ListBox antes de mostrar la nueva matriz
                listBoxOriginal.Items.Clear();

                // Llenar la matriz con valores aleatorios y mostrarla en el ListBox
                for (int i = 0; i < dimension; i++)
                {
                    string fila = "";
                    for (int j = 0; j < dimension; j++)
                    {
                        matriz[i, j] = rand.Next(0, 100); // Valores aleatorios entre 0 y 100
                        fila += matriz[i, j] + "\t"; // Concatenar los valores de la fila
                    }
                    listBoxOriginal.Items.Add(fila); // A�adir la fila al ListBox
                }
            }
            else
            {
                MessageBox.Show("Por favor ingrese una dimensi�n v�lida.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTraspuerta_Click(object sender, EventArgs e)
        {
            if (matriz != null)
            {
                // Limpiar el ListBox de la matriz traspuesta
                listBoxTraspuesta.Items.Clear();

                // Calcular la traspuesta de la matriz
                for (int i = 0; i < dimension; i++)
                {
                    string fila = "";
                    for (int j = 0; j < dimension; j++)
                    {
                        fila += matriz[j, i] + "\t"; // Intercambiar filas por columnas
                    }
                    listBoxTraspuesta.Items.Add(fila); // A�adir la fila transpuesta al ListBox
                }
            }
            else
            {
                MessageBox.Show("Primero genere una matriz.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listBoxOriginal_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBoxTraspuesta_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
