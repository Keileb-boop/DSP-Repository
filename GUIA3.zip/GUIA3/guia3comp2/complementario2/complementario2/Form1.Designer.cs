﻿namespace complementario2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtDimension = new TextBox();
            btnGenerar = new Button();
            btnTraspuerta = new Button();
            listBoxOriginal = new ListBox();
            listBoxTraspuesta = new ListBox();
            SuspendLayout();
            // 
            // txtDimension
            // 
            txtDimension.Location = new Point(62, 84);
            txtDimension.Name = "txtDimension";
            txtDimension.Size = new Size(125, 27);
            txtDimension.TabIndex = 0;
            txtDimension.TextChanged += txtDimension_TextChanged;
            // 
            // btnGenerar
            // 
            btnGenerar.Location = new Point(203, 84);
            btnGenerar.Name = "btnGenerar";
            btnGenerar.Size = new Size(148, 29);
            btnGenerar.TabIndex = 1;
            btnGenerar.Text = "Generar Matriz";
            btnGenerar.UseVisualStyleBackColor = true;
            btnGenerar.Click += btnGenerar_Click;
            // 
            // btnTraspuerta
            // 
            btnTraspuerta.Location = new Point(203, 131);
            btnTraspuerta.Name = "btnTraspuerta";
            btnTraspuerta.Size = new Size(148, 29);
            btnTraspuerta.TabIndex = 2;
            btnTraspuerta.Text = "Calcular Traspuesta";
            btnTraspuerta.UseVisualStyleBackColor = true;
            btnTraspuerta.Click += btnTraspuerta_Click;
            // 
            // listBoxOriginal
            // 
            listBoxOriginal.FormattingEnabled = true;
            listBoxOriginal.Location = new Point(62, 198);
            listBoxOriginal.Name = "listBoxOriginal";
            listBoxOriginal.Size = new Size(250, 104);
            listBoxOriginal.TabIndex = 3;
            listBoxOriginal.SelectedIndexChanged += listBoxOriginal_SelectedIndexChanged;
            // 
            // listBoxTraspuesta
            // 
            listBoxTraspuesta.FormattingEnabled = true;
            listBoxTraspuesta.Location = new Point(405, 198);
            listBoxTraspuesta.Name = "listBoxTraspuesta";
            listBoxTraspuesta.Size = new Size(223, 104);
            listBoxTraspuesta.TabIndex = 4;
            listBoxTraspuesta.SelectedIndexChanged += listBoxTraspuesta_SelectedIndexChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(759, 403);
            Controls.Add(listBoxTraspuesta);
            Controls.Add(listBoxOriginal);
            Controls.Add(btnTraspuerta);
            Controls.Add(btnGenerar);
            Controls.Add(txtDimension);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtDimension;
        private Button btnGenerar;
        private Button btnTraspuerta;
        private ListBox listBoxOriginal;
        private ListBox listBoxTraspuesta;
    }
}
