using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Aplicacionwebtst.Pages.usuarios
{
    public class loginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
