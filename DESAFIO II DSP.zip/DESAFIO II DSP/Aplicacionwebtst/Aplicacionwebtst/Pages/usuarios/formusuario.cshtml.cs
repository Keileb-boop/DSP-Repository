using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Aplicacionwebtst.Pages.usuarios
{
    public class formusuarioModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
