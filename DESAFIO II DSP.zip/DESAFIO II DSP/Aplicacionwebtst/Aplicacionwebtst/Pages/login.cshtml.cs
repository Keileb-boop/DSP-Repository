using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Aplicacionwebtst.Pages
{
    public class loginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
